# pyBallMapper

Python version of the Ball Mapper algorithm
https://rdrr.io/cran/BallMapper/

the notebook contains an example and tools for visualize the graph using Bokeh. 
